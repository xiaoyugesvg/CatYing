// POC 适配层：把 esbuild 打包的配置规范化成宿主可直接用的对象，
// 并把「自定义爬虫目录」指到本包内的可写目录（iOS 沙盒里 /data 不可写）。
const path = require('path');
if (!process.env.CATPAW_CUSTOM_SPIDER_DIR) {
  process.env.CATPAW_CUSTOM_SPIDER_DIR = path.join(__dirname, '..', 'custom-spiders');
}
let m = {};
try { m = require('./index.config.orig.js') || {}; } catch (_) { m = {}; }
module.exports = (m && m.default) ? m.default : m;
